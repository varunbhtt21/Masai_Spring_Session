package com.masai.microservice.currencyexchangeservice.controller;

import com.masai.microservice.currencyexchangeservice.entity.ExchangeValue;
import com.masai.microservice.currencyexchangeservice.repository.ExchangeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;

@RestController
public class CurrencyExchange {

    @Autowired
    Environment environment;

    @Autowired
    ExchangeRepository exchangeRepository;

    @GetMapping("/currency-exchange/from/{from}/to/{to}")
    public ExchangeValue retrieveExchangeValue(@PathVariable("from") String from,
                                               @PathVariable("to") String to){

        ExchangeValue exchangeValue = new ExchangeValue(1000L, from , to, BigDecimal.valueOf(65));
//        ExchangeValue exchangeValue = exchangeRepository.findByFromAndTo("INR","US");
//        exchangeValue.setPort(
//                Integer.parseInt(environment.getProperty("local.server.port")));
        return exchangeValue;
    }

}
