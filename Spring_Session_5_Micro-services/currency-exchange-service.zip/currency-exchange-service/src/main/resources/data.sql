INSERT INTO EXCHANGE_VALUE(id, currency_from, currency_to,conversion_multiple, port)
VALUES(102L, 'INR', 'US', 65, 0);