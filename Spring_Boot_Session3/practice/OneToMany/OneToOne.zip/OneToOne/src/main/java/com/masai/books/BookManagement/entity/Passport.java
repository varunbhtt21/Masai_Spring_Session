package com.masai.books.BookManagement.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Passport  {

    @Id
    private Long passportId;
    private String passportNumber;

    @JsonBackReference
    @OneToOne(mappedBy = "passport")
    private Student student;

}
