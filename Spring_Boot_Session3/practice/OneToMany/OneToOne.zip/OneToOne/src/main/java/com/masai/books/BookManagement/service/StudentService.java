package com.masai.books.BookManagement.service;

import com.masai.books.BookManagement.entity.Passport;
import com.masai.books.BookManagement.entity.Student;
import com.masai.books.BookManagement.repository.PassportRepository;
import com.masai.books.BookManagement.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StudentService {

    @Autowired
    StudentRepository studentRepository;


    @Autowired
    PassportRepository passportRepository;

    public List<Student> getAllStudents(){
        List<Student> students = studentRepository.findAll();
        return students;
    }

    public Student addStudent(Student student) {

        Student student1 = studentRepository.save(student);
        return student1;
    }


    public Student updateStudent(Student student) {
        Student student1 = studentRepository.findById(student.getId()).get();
        student1.setStudentName(student.getStudentName());
        student1.setStudentName(student.getStudentName());
        studentRepository.save(student1);

        return student1;
    }


    public boolean deleteStudent(Long studentId) {
        Student student = studentRepository.findById(studentId).get();

        try{
            studentRepository.delete(student);
            return true;
        }
        catch (Exception ex){
            return false;
        }
    }


    public Student addPassport(Passport passport, Long studentId) {

        // Getting th student Obj
        Student student = studentRepository.findById(studentId).get();

        // Check weather passport Exist

        Optional<Passport> passport1 = passportRepository.findById(passport.getPassportId());

        if(passport1.isPresent()){
            student.setPassport(passport1.get());
            studentRepository.save(student);
        }
        else{

            //Save Passport info to passport database
            passportRepository.save(passport);
            student.setPassport(passport);
            studentRepository.save(student);
        }

        return student;
    }


    public Student getStudent(Long studentId) {
        Student student = studentRepository.findById(studentId).get();
        return student;
    }
}
