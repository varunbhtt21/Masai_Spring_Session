package com.masai.books.BookManagement.entity;


import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table( uniqueConstraints = { @UniqueConstraint(columnNames = {"passport_id"})})
@NoArgsConstructor
@AllArgsConstructor
@Data
public class Student  {

    @Id
    private Long id;

    @Column(nullable = false)
    private String studentName;

    @JsonManagedReference
    @OneToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    @JoinColumn(name="passport_id",insertable=false, updatable=false)
    private Passport passport;



}
