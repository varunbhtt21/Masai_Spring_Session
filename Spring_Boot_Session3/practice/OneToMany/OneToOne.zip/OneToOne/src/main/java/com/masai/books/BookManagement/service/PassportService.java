package com.masai.books.BookManagement.service;


import com.masai.books.BookManagement.entity.Passport;
import com.masai.books.BookManagement.entity.Student;
import com.masai.books.BookManagement.repository.PassportRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PassportService {

    @Autowired
    PassportRepository passportRepository;

    public List<Passport> getAllPassport() {
        return passportRepository.findAll();
    }


    public Passport insertPassport(Passport passport) {
        return passportRepository.save(passport);

    }

    public boolean deletePassport(Long passportId) {
        Passport passport = passportRepository.findById(passportId).get();

        try{
            passportRepository.delete(passport);
            return true;
        }
        catch (Exception ex){
            return false;
        }
    }


    public Passport updatePassport(Passport passport) {
        Passport passport1 = passportRepository.findById(passport.getPassportId()).get();
        passport1.setPassportNumber(passport.getPassportNumber());
        passportRepository.save(passport1);
        return passport1;
    }


}
